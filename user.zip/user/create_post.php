<?php
session_start();

if (!isset($_SESSION['id'])) {
    // Redirect to login page if user is not logged in
    header('Location: https://phpfortech.in/user_login.php');
    exit();
}

$servername = "localhost";
$username = "u440868973_submituser";
$password = "yH2JHFsAycn2R6i";

try {
    $pdo = new PDO("mysql:host=$servername;dbname=u440868973_submitdb", $username, $password);
    // set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input data
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $url = filter_input(INPUT_POST, 'url', FILTER_SANITIZE_URL);
    $des = filter_input(INPUT_POST, 'des', FILTER_SANITIZE_STRING);

    // Handle file upload
   $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $imageFilename = uniqid() . '.' . $imageFileType;
    $imagePath = $target_dir . $imageFilename;

    // Check if file is a valid image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check === false) {
        echo "File is not an image.";
        exit();
    }

    // Check file size
    if ($_FILES["image"]["size"] > 5000000) { // 5 MB
        echo "Sorry, your file is too large.";
        exit();
    }

    // Allow only certain file formats
    if($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png" && $imageFileType != "gif" ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        exit();
    }

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $imagePath)) {
        // File uploaded successfully, insert data into database
        // Prepare insert query
        $stmt = $pdo->prepare('INSERT INTO upload_image (login_id, title, url, image, des, upload_date) VALUES (:login_id, :title, :url, :image, :des, NOW())');

        // Bind parameters and execute query
        try {
            $stmt->bindParam(':login_id', $_SESSION['id'], PDO::PARAM_INT);
            $stmt->bindParam(':title', $title, PDO::PARAM_STR);
            $stmt->bindParam(':url', $url, PDO::PARAM_STR);
            $stmt->bindParam(':image', $imageFilename, PDO::PARAM_STR);
            $stmt->bindParam(':des', $des, PDO::PARAM_STR);
            $stmt->execute();

            // Redirect to success page
            header('Location: https://phpfortech.in/user/');
            exit();
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    } else {
        // Failed to upload file
        echo 'Error uploading file';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Image Upload Page</title>
 <style>
     body {
  margin: 0;
  padding: 0;
  font-family: sans-serif;
  font-size: 16px;
  line-height: 1.5;
  background-color: #f8f8f8;
}

header {
  background-color: #333;
  color: #fff;
  padding: 10px 20px;
  text-align: center;
}

main {
  max-width: 600px;
  margin: 20px auto;
  padding: 20px;
  background-color: #fff;
  box-shadow: 0 0 10px rgba(0,0,0,0.2);
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

input[type="text"],
input[type="url"],
textarea {
  display: block;
  width: 100%;
  padding: 8px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

textarea {
  height: 100px;
}

button[type="submit"] {
  display: block;
  margin: 20px auto 0;
  padding: 10px 20px;
  background-color: #333;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

button[type="submit"]:hover {
  background-color: #555;
}

.ad {
  text-align: center;
  margin-top: 20px;
}

.ad img {
  max-width: 100%;
  height: auto;
}

 </style>
</head>
<body>
  <header>
    <h1>Create Post Page</h1>
  </header>
  <main>
    <form action="#" method="POST" enctype="multipart/form-data">
      <label for="image">Select Image</label>
      <input type="file" name="image" id="image" >
      <label for="title" style="padding-top: 15px;">Title</label>
      <input type="text" name="title" id="title" maxlength="50" >
      <label for="url">Website URL</label>
      <input type="url" name="url" id="url" required>
      <label for="description">Image Description (max 30 words)</label>
      <textarea name="des" id="des" maxlength="30" ></textarea>
      <button type="submit">Upload</button>
    </form>
  </main>
  <aside>
    <div class="ad">
      <img src="https://via.placeholder.com/320x100.png?text=Horizontal+Ad+Banner" alt="Horizontal Ad Banner">
    </div>
  </aside>
</body>
</html>
