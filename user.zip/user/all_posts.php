<!DOCTYPE html>
<html>
<head>
	<title>Image Gallery</title>
	<style>
		.image-container {
			display: flex;
			flex-wrap: wrap;
			justify-content: space-between;
			margin: 20px;
		}

		.image {
			width: 18%;
			margin-bottom: 20px;
			text-align: center;
		}

		.image img {
			max-width: 100%;
			max-height: 100%;
		}

		.image-title {
			font-size: 16px;
			font-weight: bold;
			margin-bottom: 10px;
		}

		.image-description {
			font-size: 14px;
		}
	</style>
</head>
<body>
	<div class="image-container">
		<div class="image">
			<div class="image-title">Image 1</div>
			<img src="image1.jpg">
			<div class="image-description">This is the description for Image 1.</div>
		</div>
		<div class="image">
			<div class="image-title">Image 2</div>
			<img src="image2.jpg">
			<div class="image-description">This is the description for Image 2.</div>
		</div>
		<div class="image">
			<div class="image-title">Image 3</div>
			<img src="image3.jpg">
			<div class="image-description">This is the description for Image 3.</div>
		</div>
		<div class="image">
			<div class="image-title">Image 4</div>
			<img src="image4.jpg">
			<div class="image-description">This is the description for Image 4.</div>
		</div>
		<div class="image">
			<div class="image-title">Image 5</div>
			<img src="image5.jpg">
			<div class="image-description">This is the description for Image 5.</div>
		</div>
		<!-- Repeat this pattern for additional images -->
	</div>
</body>
</html>
