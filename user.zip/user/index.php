<?php
session_start();


if (!isset($_SESSION['id'])) {
    // Redirect to login page if user is not logged in
    header('Location: https://phpfortech.in/user_login.php');
    exit();
}

    $dsn = 'mysql:host=localhost;dbname=u440868973_submitdb';
    $dbUsername = 'u440868973_submituser';
    $dbPassword = 'yH2JHFsAycn2R6i';

try {
    $pdo = new PDO($dsn, $dbUsername, $dbPassword);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare('SELECT * FROM login WHERE id = :id');
    $stmt->execute(array(
        ':id' => $_SESSION['id']
    ));
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        // Invalid user ID, redirect to login page
        header('Location: https://phpfortech.in/test/login.php');
        exit();
    }
} catch (PDOException $e) {
    $error = 'Error: ' . $e->getMessage();
}

// total today post count
$today = date('Y-m-d');
$stmt = $pdo->prepare('SELECT COUNT(*) as count FROM upload_image WHERE login_id = :login_id AND DATE(upload_date) = :today');
$stmt->bindParam(':login_id', $_SESSION['id'], PDO::PARAM_INT);
$stmt->bindParam(':today', $today, PDO::PARAM_STR);
$stmt->execute();
$count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];

// total post count
$stmt = $pdo->prepare('SELECT COUNT(*) as total_posts FROM upload_image WHERE login_id = :login_id');
$stmt->bindParam(':login_id', $_SESSION['id'], PDO::PARAM_INT);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);


// Select 4 random images uploaded by other users
$stmt = $pdo->prepare('SELECT * FROM upload_image WHERE login_id != :login_id ORDER BY RAND() LIMIT 4');
$stmt->bindParam(':login_id', $_SESSION['id'], PDO::PARAM_INT);
$stmt->execute();

// Fetch the selected images as an associative array and store them in a variable
$other_user_images = $stmt->fetchAll(PDO::FETCH_ASSOC);



// Select the last uploaded image by the user
$stmt = $pdo->prepare('SELECT * FROM upload_image WHERE login_id = :login_id ORDER BY id DESC LIMIT 1');
$stmt->bindParam(':login_id', $_SESSION['id'], PDO::PARAM_INT);
$stmt->execute();

// Fetch the selected image as an associative array
$image = $stmt->fetch(PDO::FETCH_ASSOC);


// Set the default profile picture if the user has not uploaded one
if (!$user['user_image']) {
    $user['user_image'] = 'default_profile.jpg';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>Material Pro Admin Template - The Most Complete & Trusted Bootstrap 4 Admin Template</title>
    <!-- Bootstrap Core CSS -->
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- chartist CSS -->
    <link href="assets/plugins/chartist-js/dist/chartist.min.css" rel="stylesheet">
    <link href="assets/plugins/chartist-js/dist/chartist-init.css" rel="stylesheet">
    <link href="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <!--This page css - Morris CSS -->
    <link href="assets/plugins/c3-master/c3.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
     
  
  .upload-btn-wrapper {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background-color: rgba(255, 255, 255, 0.8);
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
  }
  
  .upload-btn-wrapper:hover {
    opacity: 1;
  }
  
  .upload-btn-wrapper .btn {
    padding: 8px 20px;
    background-color: #2c3e50;
    color: #fff;
    border-radius: 4px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
  }
  
  .upload-btn-wrapper input[type=file] {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    opacity: 0;
    cursor: pointer;
  }
</style>
</head>

<body class="fix-header fix-sidebar card-no-border">
     
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
            <nav class="navbar top-navbar navbar-toggleable-sm navbar-light">
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.html">
                        <!-- Logo icon --><b>
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            
                            <!-- Light Logo icon -->
                            <img src="assets/images/logo-light-icon.png" alt="homepage" class="light-logo" />
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text --><span>
                         
                         <!-- Light Logo text -->    
                         <img src="assets/images/logo-light-text.png" class="light-logo" alt="homepage" /></span> </a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                        <li class="nav-item hidden-sm-down search-box"> <a class="nav-link hidden-sm-down text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="ti-search"></i></a>
                            <form class="app-search">
                                <input type="text" class="form-control" placeholder="Search & enter"> <a class="srh-btn"><i class="ti-close"></i></a> </form>
                        </li>
                    </ul>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav my-lg-0">
                        <!-- ============================================================== -->
                        <!-- Profile -->
                        <!-- ============================================================== -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="https://phpfortech.in/<?php echo $user['user_image']; ?>" alt="user" class="profile-pic m-r-10" /><?= $user['name'] ?></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li> <a class="waves-effect waves-dark" href="index.php" aria-expanded="false"><i class="mdi mdi-gauge"></i><span class="hide-menu">Dashboard</span></a>
                        </li>
                         <li> <a class="waves-effect waves-dark" href="all_posts.php" aria-expanded="false"><i class="mdi mdi-animation"></i><span class="hide-menu">Posts</span></a>
                        </li>
                        <li> <a class="waves-effect waves-dark" href="pages-profile.html" aria-expanded="false"><i class="mdi mdi-account-check"></i><span class="hide-menu">Profile</span></a>
                        </li>
                        <!--<li> <a class="waves-effect waves-dark" href="table-basic.html" aria-expanded="false"><i class="mdi mdi-table"></i><span class="hide-menu">Basic Table</span></a>-->
                        <!--</li>-->
                        <!--<li> <a class="waves-effect waves-dark" href="icon-material.html" aria-expanded="false"><i class="mdi mdi-emoticon"></i><span class="hide-menu">Icons</span></a>-->
                        <!--</li>-->
                        <!--<li> <a class="waves-effect waves-dark" href="map-google.html" aria-expanded="false"><i class="mdi mdi-earth"></i><span class="hide-menu">Google Map</span></a>-->
                        <!--</li>-->
                        <!--<li> <a class="waves-effect waves-dark" href="pages-blank.html" aria-expanded="false"><i class="mdi mdi-book-open-variant"></i><span class="hide-menu">Blank Page</span></a>-->
                        <!--</li>-->
                        <!--<li> <a class="waves-effect waves-dark" href="pages-error-404.html" aria-expanded="false"><i class="mdi mdi-help-circle"></i><span class="hide-menu">Error 404</span></a>-->
                        <!--</li>-->
                    </ul>
                    <div class="text-center m-t-30">
                        <!--<a href="https://themewagon.com/themes/bootstrap-4-responsive-admin-template/" class="btn waves-effect waves-light btn-warning hidden-md-down">Download Now</a>-->
                    </div>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
            <!-- Bottom points-->
            <div class="sidebar-footer">
                <!-- item--><a href="" class="link" data-toggle="tooltip" title="Settings"><i class="ti-settings"></i></a>
                <!-- item--><a href="" class="link" data-toggle="tooltip" title="Email"><i class="mdi mdi-gmail"></i></a>
                <!-- item--><a href="user_logout.php?id=<?php echo $_SESSION['id']; ?>" class="link" data-toggle="tooltip" title="Logout"><i class="mdi mdi-power"></i></a> </div>
            <!-- End Bottom points-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 col-8 align-self-center">
                        <h3 class="text-themecolor">Dashboard</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                    <div class="col-md-7 col-4 align-self-center">
                        <a href="create_post.php?id=<?php echo $_SESSION['id']; ?>" class="btn waves-effect waves-light btn-danger pull-right hidden-sm-down">Create Post</a>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-8 col-md-7">
                        <div class="card">
                            <div class="card-block">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="d-flex flex-wrap">
                                            <div>
                                                <h3 class="card-title">Latest Image Upload</h3>
                                                <!--<h6 class="card-subtitle">Ample Admin Vs Pixel Admin</h6> -->
                                                </div>
                                            <div class="ml-auto">
                                                <ul class="list-inline">
                                                    <li>
                                                        <!--<h6 class="text-muted text-success"><i class="fa fa-circle font-10 m-r-10 "></i>Ample</h6> -->
                                                        </li>
                                                    <li>
                                                        <!--<h6 class="text-muted  text-info"><i class="fa fa-circle font-10 m-r-10"></i>Pixel</h6> -->
                                                        </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-12">
                         <div class=""  >
                                  <?php
                                    if ($image) {
                                     // Construct the image URL using the filename
                                       $image_url = 'uploads/' . $image['image'];

                                     // Display the image with max-width and max-height set to 100%
                                      echo '<img src="' . $image_url . '" alt="Last uploaded image" style="max-width:100%; max-height:100%;">';
                                            } else {
                                            // No image found
                                              echo '<p>No image found.</p>';
                                            }
                                            ?>
                                            </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-5">
                        <div class="card">
                            <div class="card-block">
                                <h3 class="card-title">Convert to WEBP </h3>
                                <h6 class="card-subtitle">Different Devices Used to Visit</h6>
                                <div id="visitor" style="height:290px; width:100%;"></div>
                            </div>
                            <div>
                                <hr class="m-t-0 m-b-0">
                            </div>
                            <div class="card-block text-center ">
                                <ul class="list-inline m-b-0">
                                    <li>
                                        <h6 class="text-muted text-info"><i class="fa fa-circle font-10 m-r-10 "></i>Mobile</h6> </li>
                                    <li>
                                        <h6 class="text-muted  text-primary"><i class="fa fa-circle font-10 m-r-10"></i>Desktop</h6> </li>
                                    <li>
                                        <h6 class="text-muted  text-success"><i class="fa fa-circle font-10 m-r-10"></i>Tablet</h6> </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Row -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-xlg-3 col-md-5">
                        <!-- Column -->
                        <div class="card">
                            <img class="card-img-top" src="assets/images/background/profile-bg.jpg" alt="Card image cap">
                            <div class="card-block little-profile text-center">
                               <div class="pro-img" onclick="openImageUpload()">
  <img id="profile-image" src="https://phpfortech.in/<?php echo $user['user_image']; ?>" alt="user" />
</div>


<!-- Image upload form -->
<div class="upload-btn-wrapper">
    <button class="btn">Upload a photo</button>
    <input type="file" name="profile-pic" accept="image/*">
  </div>
                                <h3 class="m-b-0"><?= $user['name'] ?></h3>
                                <p>@<?= $user['uname'] ?></p>
                                <!--<a href="javascript:void(0)" class="m-t-10 waves-effect waves-dark btn btn-primary btn-md btn-rounded">Follow</a>-->
                                <div class="row text-center m-t-20">
                                    <div class="col-lg-4 col-md-4 m-t-20">
                                        <h3 class="m-b-0 font-light"><?php echo $count; ?></h3><small>Today Post</small></div>
                                    <div class="col-lg-4 col-md-4 m-t-20">
                                        <h3 class="m-b-0 font-light"><?php echo $result['total_posts']; ?></h3><small>Total Post</small></div>
                                    <div class="col-lg-4 col-md-4 m-t-20">
                                        <h3 class="m-b-0 font-light">6035</h3><small>Total Like</small>
                                        </div>
                                </div>
                            </div>
                        </div>
                        <!-- Column -->
                        <div class="card">
                            <div class="card-block bg-info">
                                <h4 class="text-white card-title">Create Post Here</h4>
                                <h6 class="card-subtitle text-white m-b-0 op-5">Only we support WEBP Image </h6>
                            </div>
                            <div class="card-block">
                                <div class="message-box contact-box">
                                    <h2 class="add-ct-btn"><button type="button" class="btn btn-circle btn-lg btn-success waves-effect waves-dark">+</button></h2>
                                    <div class="message-widget contact-widget">
                                        <!-- Message -->
                                        <a href="#">
                                            <div class="user-img"> <img src="assets/images/users/1.jpg" alt="user" class="img-circle"> <span class="profile-status online pull-right"></span> </div>
                                            <div class="mail-contnet">
                                                <h5>Pavan kumar</h5> <span class="mail-desc">info@wrappixel.com</span></div>
                                        </a>
                                        <!-- Message -->
                                        <a href="#">
                                            <div class="user-img"> <img src="assets/images/users/2.jpg" alt="user" class="img-circle"> <span class="profile-status busy pull-right"></span> </div>
                                            <div class="mail-contnet">
                                                <h5>Sonu Nigam</h5> <span class="mail-desc">pamela1987@gmail.com</span></div>
                                        </a>
                                        <!-- Message -->
                                        <a href="#">
                                            <div class="user-img"> <span class="round">A</span> <span class="profile-status away pull-right"></span> </div>
                                            <div class="mail-contnet">
                                                <h5>Arijit Sinh</h5> <span class="mail-desc">cruise1298.fiplip@gmail.com</span></div>
                                        </a>
                                        <!-- Message -->
                                        <a href="#">
                                            <div class="user-img"> <img src="assets/images/users/4.jpg" alt="user" class="img-circle"> <span class="profile-status offline pull-right"></span> </div>
                                            <div class="mail-contnet">
                                                <h5>Pavan kumar</h5> <span class="mail-desc">kat@gmail.com</span></div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8 col-xlg-9 col-md-7">
                        <div class="card">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs profile-tab" role="tablist">
                                <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab">Activity</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Profile</a> </li>
                                <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#settings" role="tab">Settings</a> </li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="home" role="tabpanel">
                                    <div class="card-block">
                                        <div class="profiletimeline">
                                            <div class="sl-item">
                                                <div class="sl-left"> <img src="https://phpfortech.in/<?php echo $user['user_image']; ?>" alt="user" class="img-circle"> </div>
                                                <div class="sl-right">
                                                    <div>
                                                        <a href="#" class="link"><?= $user['name'] ?></a>
                                                        <!--<span class="sl-date">5 minutes ago</span>-->
                                                        <p></p>
                                                      <div class="row">
                                                             <?php
                                                            // Fetch last 4 images for the logged in user
                                                            $stmt = $pdo->prepare('SELECT * FROM upload_image WHERE login_id = :login_id ORDER BY id DESC LIMIT 4');
                                                            $stmt->bindParam(':login_id', $_SESSION['id'], PDO::PARAM_INT);
                                                            $stmt->execute();
                                                            $images = $stmt->fetchAll(PDO::FETCH_ASSOC);

                                                           // Display the last 4 images in the div
                                                          for ($i = count($images) - 1; $i >= 0 && $i >= count($images) - 4; $i--) {
                                                          $imagePath = 'uploads/' . $images[$i]['image'];
                                                          echo "<div class='col-lg-3 col-md-6 m-b-20'><img src='$imagePath' alt='{$images[$i]['title']}' class='img-responsive radius'></div>";
                                                            }
                                                            ?>
                                                          </div>
                                                        <div class="like-comm"> <a href="javascript:void(0)" class="link m-r-10">2 comment</a> <a href="javascript:void(0)" class="link m-r-10"><i class="fa fa-heart text-danger"></i> 5 Love</a> </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="sl-item">
                                                <!--<div class="sl-left"> <img src="assets/images/users/2.jpg" alt="user" class="img-circle"> </div>-->
                                                <div class="sl-right">
                                                  
                                                    <div> <h3><a href="#" class="link">Other's visitor posts</a>   </h3>
                                                    
                                                    
                                                    
                                                    <?php foreach ($other_user_images as $image): ?>
                                                    <!--<span class="sl-date">5 minutes ago</span>-->
                                                        <div class="m-t-20 row">
                                                            <div class="col-md-3 col-xs-12">
                                                                <img src='uploads/<?php echo $image['image']; ?>' alt='<?php echo $image['title']; ?>' class='img-responsive radius'>
                                                                </div>
                                                            <div class="col-md-9 col-xs-12">
                                                               <p><?php echo $image['des']; ?></p>
                                                                <a href="#" class="btn btn-success"> Visit Post</a></div>
                                                        </div>
                                                        
                                                        <?php endforeach; ?>
                                                        
                                                        
                                                        
                                                        
                                                        <!--<div class="like-comm m-t-20"> <a href="javascript:void(0)" class="link m-r-10">2 comment</a> <a href="javascript:void(0)" class="link m-r-10"><i class="fa fa-heart text-danger"></i> 5 Love</a> </div>-->
                                                         <!--<div class="m-t-20 row">-->
                                                            <!--<div class="col-md-3 col-xs-12"><img src="assets/images/big/img1.jpg" alt="user" class="img-responsive radius"></div>-->
                                                            <!--<div class="col-md-9 col-xs-12">-->
                                                            <!--    <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. </p> <a href="#" class="btn btn-success"> Visit Post</a></div>-->
                                                        <!--         <div class="m-t-20 row">-->
                                                        <!--    <div class="col-md-3 col-xs-12"><img src="assets/images/big/img1.jpg" alt="user" class="img-responsive radius"></div>-->
                                                        <!--    <div class="col-md-9 col-xs-12">-->
                                                        <!--        <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. </p> <a href="#" class="btn btn-success"> Visit Post</a></div>-->
                                                        <!--</div>-->
                                                        <!-- <div class="m-t-20 row">-->
                                                        <!--    <div class="col-md-3 col-xs-12"><img src="assets/images/big/img1.jpg" alt="user" class="img-responsive radius"></div>-->
                                                        <!--    <div class="col-md-9 col-xs-12">-->
                                                        <!--        <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. </p> <a href="#" class="btn btn-success"> Visit Post</a></div>-->
                                                        <!--</div>-->
                                                        <!--</div>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <!--<div class="sl-item">-->
                                            <!--    <div class="sl-left"> <img src="assets/images/users/3.jpg" alt="user" class="img-circle"> </div>-->
                                            <!--    <div class="sl-right">-->
                                            <!--        <div><a href="#" class="link">John Doe</a> <span class="sl-date">5 minutes ago</span>-->
                                            <!--            <p class="m-t-10"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante dapibus diam. Sed nisi. Nulla quis sem at nibh elementum imperdiet. Duis sagittis ipsum. Praesent mauris. Fusce nec tellus sed augue semper </p>-->
                                            <!--        </div>-->
                                            <!--        <div class="like-comm m-t-20"> <a href="javascript:void(0)" class="link m-r-10">2 comment</a> <a href="javascript:void(0)" class="link m-r-10"><i class="fa fa-heart text-danger"></i> 5 Love</a> </div>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            <hr>
                                            <!--<div class="sl-item">-->
                                            <!--    <div class="sl-left"> <img src="assets/images/users/4.jpg" alt="user" class="img-circle"> </div>-->
                                            <!--    <div class="sl-right">-->
                                            <!--        <div><a href="#" class="link">John Doe</a> <span class="sl-date">5 minutes ago</span>-->
                                            <!--            <blockquote class="m-t-10">-->
                                            <!--                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt-->
                                            <!--            </blockquote>-->
                                            <!--        </div>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                        </div>
                                    </div>
                                </div>
                                <!--second tab-->
                                <div class="tab-pane" id="profile" role="tabpanel">
                                    <div class="card-block">
                                        <div class="row">
                                            <div class="col-md-3 col-xs-6 b-r"> <strong>Full Name</strong>
                                                <br>
                                                <p class="text-muted"><?= $user['name'] ?></p>
                                            </div>
                                            <div class="col-md-3 col-xs-6 b-r"> <strong>Mobile</strong>
                                                <br>
                                                <p class="text-muted"><?= $user['mobile'] ?></p>
                                            </div>
                                            <div class="col-md-3 col-xs-6 b-r"> <strong>Email</strong>
                                                <br>
                                                <p class="text-muted"><?= $user['email'] ?></p>
                                            </div>
                                            <div class="col-md-3 col-xs-6"> <strong>Join Date</strong>
                                                <br>
                                                <p class="text-muted"><?= $user['reg_date'] ?></p>
                                            </div>
                                        </div>
                                        <hr>
                                        <p class="m-t-30"><?= $user['about'] ?> </p>
                                        
                                        <h4 class="font-medium m-t-30">Skill Set</h4>
                                        <hr>
                                        <h5 class="m-t-30">Wordpress <span class="pull-right">80%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar bg-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width:80%; height:6px;"> <span class="sr-only">50% Complete</span> </div>
                                        </div>
                                        <h5 class="m-t-30">HTML 5 <span class="pull-right">90%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar bg-info" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:90%; height:6px;"> <span class="sr-only">50% Complete</span> </div>
                                        </div>
                                        <h5 class="m-t-30">jQuery <span class="pull-right">50%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:50%; height:6px;"> <span class="sr-only">50% Complete</span> </div>
                                        </div>
                                        <h5 class="m-t-30">Photoshop <span class="pull-right">70%</span></h5>
                                        <div class="progress">
                                            <div class="progress-bar bg-warning" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%; height:6px;"> <span class="sr-only">50% Complete</span> </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane" id="settings" role="tabpanel">
                                    <div class="card-block">
                                        <form class="form-horizontal form-material">
                                            <div class="form-group">
                                                <label class="col-md-12">Full Name</label>
                                                <div class="col-md-12">
                                                    <input type="text" value="<?= $user['name'] ?>" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="example-email" class="col-md-12">Email</label>
                                                <div class="col-md-12">
                                                    <input type="email" value="<?= $user['email'] ?>" class="form-control form-control-line" name="example-email" id="example-email">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Password</label>
                                                <div class="col-md-12">
                                                    <input type="password" value="<?= $user['pass'] ?>" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">Phone No</label>
                                                <div class="col-md-12">
                                                    <input type="text" value="<?= $user['mobile'] ?>" class="form-control form-control-line">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-12">About</label>
                                                <div class="col-md-12">
                                                    <textarea rows="5" class="form-control form-control-line"><?= $user['about'] ?></textarea>
                                                </div>
                                            </div>
                                            <!--<div class="form-group">-->
                                            <!--    <label class="col-sm-12">Select Country</label>-->
                                            <!--    <div class="col-sm-12">-->
                                            <!--        <select class="form-control form-control-line">-->
                                            <!--            <option>London</option>-->
                                            <!--            <option>India</option>-->
                                            <!--            <option>Usa</option>-->
                                            <!--            <option>Canada</option>-->
                                            <!--            <option>Thailand</option>-->
                                            <!--        </select>-->
                                            <!--    </div>-->
                                            <!--</div>-->
                                            <div class="form-group">
                                                <div class="col-sm-12">
                                                    <button class="btn btn-success">Update Profile</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <footer class="footer"> © 2017 Material Pro Admin by wrappixel.com </footer>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="assets/plugins/bootstrap/js/tether.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="js/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <!--Custom JavaScript -->
    <script src="js/custom.min.js"></script>
    <!-- ============================================================== -->
    <!-- This page plugins -->
    <!-- ============================================================== -->
    <!-- chartist chart -->
    <script src="assets/plugins/chartist-js/dist/chartist.min.js"></script>
    <script src="assets/plugins/chartist-plugin-tooltip-master/dist/chartist-plugin-tooltip.min.js"></script>
    <!--c3 JavaScript -->
    <script src="assets/plugins/d3/d3.min.js"></script>
    <script src="assets/plugins/c3-master/c3.min.js"></script>
    <!-- Chart JS -->
    <script src="js/dashboard1.js"></script>
    <script>
         // Add event listener to the profile pic div
  const profilePic = document.querySelector('.profile-pic');
  profilePic.addEventListener('click', function() {
    // Click event handler
    const uploadBtnWrapper = this.querySelector('.upload-btn-wrapper');
    uploadBtnWrapper.style.opacity = '1';
  });
  
  // Add event listener to the file input
  const fileInput = document.querySelector('input[name=profile-pic]');
  fileInput.addEventListener('change', function() {
    // Change event handler
    const file = this.files[0];
    if (file) {
      // Create a FileReader object
      const reader = new FileReader();
      reader.addEventListener('load', function() {
        // Set the profile pic background image to the uploaded image
        profilePic.style.backgroundImage = `url(${this.result})`;
      });
      reader.readAsDataURL(file);
    }
  });
    </script>
  
</body>

</html>
